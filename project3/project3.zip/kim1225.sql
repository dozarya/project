-- 寃뚯떆�뙋 �뀒�씠釉� 留뚮뱾湲�
CREATE TABLE board2 (
    bno number not null primary key --寃뚯떆臾쇰쾲�샇
    ,title varchar2(200) not null   --寃뚯떆臾쇱젣紐�
    ,content varchar2(4000)         --寃뚯떆臾쇰궡�슜
    ,writer varchar2(50) not null   --寃뚯떆臾쇱옉�꽦�옄
    ,regdate date default sysdate   --寃뚯떆臾쇱옉�꽦�씪�옄
    ,viewcnt number default 0       --寃뚯떆臾쇱“�쉶�닔
);
-- �뀒�씠釉� �뜲�씠�꽣 �궘�젣
DELETE FROM board2;

-- 寃뚯떆臾� �젅肄붾뱶 120媛� �궫�엯�븯湲�
declare
i number := 1; begin
while i<=120 loop
insert into board2 (bno,title,content,writer) values
((select nvl(max(bno)+1,1) from board2) ,'제목'||i,'내용'||i,'kim');
i := i+1;
end loop; 
end;
/

-- 寃뚯떆湲��닔 議고쉶 �삉�뒗 寃뚯떆�뙋 議고쉶
select count(*) from board2; 
select * from board2;
-- commit
commit;

CREATE TABLE member2 (
    userid varchar2(100) not null primary key --�궗�슜�옄�븘�씠�뵒
    ,passwd varchar2(500) not null   --鍮꾨�踰덊샇
    ,name varchar2(100)         --�씠由�
    ,email varchar2(200) not null   --�씠硫붿씪
    ,regdate date default sysdate   --媛��엯�씪
);

insert into member2(userid, passwd, name, email) values 
('admin','1234','愿�由ъ옄','kkt09072@naver.com');

select * from member2;

